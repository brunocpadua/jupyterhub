# Copyright (c) Andreas Hilboll

from sshauthenticator.sshauthenticator import SSHAuthenticator

__all__ = [SSHAuthenticator]
